package com.experion.assignment;

import java.util.Scanner;

public class Question12_Sorting {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number of elements in array :");
		int number = scanner.nextInt();
		int array[] = new int[number];
		System.out.println("Enter the elements");
		for (int index = 0; index < number; index++)
			array[index] = scanner.nextInt();
		int countOfSwap = 0;

		for (int index = 0; index < number - 1; index++) {
			countOfSwap = 0;
			for (int j = 0; j < number - 1 - index; j++) {

				if (array[j] > array[j + 1]) {
					int temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
					countOfSwap++;
				}
			}
			if (countOfSwap == 0)
				break;
		}

		System.out.print("Ascending order = ");

		for (int index = 0; index < number; index++)
			System.out.print(array[index] + " ");

		for (int index = 0, j = number - 1; index < j; index++, j--) {
			int temp = array[index];
			array[index] = array[j];
			array[j] = temp;
		}
		System.out.println();
		System.out.print("Desccending order = ");

		for (int index = 0; index < number; index++)
			System.out.print(array[index] + " ");
	}

}
